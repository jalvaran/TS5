<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Crono</title>
    
    
    
    
        <link rel="stylesheet" href="css/cronometro.css">

    
    
    
    
  </head>

  <body>

    
    <script src='chousen/source/jquery.min.js'></script>

        <script src="js/cronometro.js"></script>
        <script src="js/funciones.js"></script>
    
    
  </body>

<?php

print("<div id='DivConsultas'>");
print("Cargando Consultas, si esto no desaparece es porque no se pudo cargar");
print("</div>");
print("<script>refresca('1000')</script>");
?>
  
</html>